"""
Paquete de utilidades para Textocorrector ELE

Este paquete contiene módulos con funciones auxiliares utilizadas en toda la aplicación,
incluyendo procesamiento de texto, visualización de datos, análisis y manejo de archivos.
"""