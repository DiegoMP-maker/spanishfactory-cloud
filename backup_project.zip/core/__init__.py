"""
Paquete de componentes principales para Textocorrector ELE
Este paquete contiene clases y funciones fundamentales para la aplicación,
incluyendo los clientes para APIs externas y la gestión del estado de sesión.
"""