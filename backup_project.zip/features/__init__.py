"""
Paquete de funcionalidades para Textocorrector ELE

Este paquete contiene los módulos principales que implementan las funcionalidades
de la aplicación, incluyendo la corrección de textos, generación de ejercicios,
simulacros de examen DELE, y herramientas complementarias.
"""