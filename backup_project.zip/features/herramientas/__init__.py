"""
Paquete de herramientas para Textocorrector ELE
Este paquete contiene módulos para las diferentes herramientas complementarias
que utilizan la API directa de OpenAI en lugar de Assistants.
"""