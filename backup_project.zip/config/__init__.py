"""
Paquete de configuración para Textocorrector ELE
Este paquete contiene configuraciones globales y prompts utilizados en la aplicación.
"""
