"""
Paquete de vistas para Textocorrector ELE

Este paquete contiene los módulos que implementan las diferentes vistas (páginas)
de la aplicación, correspondientes a cada una de las funcionalidades principales.
"""