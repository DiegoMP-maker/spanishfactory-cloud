"""
Paquete de interfaz de usuario para Textocorrector ELE

Este paquete contiene los módulos que implementan la interfaz de usuario de la aplicación,
incluyendo el layout principal, la sidebar y las diferentes vistas correspondientes a cada
funcionalidad de la aplicación.
"""